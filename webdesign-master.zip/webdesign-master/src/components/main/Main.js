import React from "react";
import Button from "@material-ui/core/Button";
import { Box } from "@material-ui/core";
import { data, data2 } from "../../data";
import Products from "./Products";
import { Suspense } from "react";
import Loading from "./Loading";
import ProgressiveImage from "react-progressive-image";
const Cards = React.lazy(() => import("./Card"));

export default function Main() {
  return (
    <div className="main">
      <div className="main__cover">
        <div className="cover__img">
          <ProgressiveImage src="https://www.3dhubs.com/images/homev2/renders/_hero/hero_SM_2560px_half.jpg"


            placeholder="gray.png" >
            {(src, loading) => <img style={{ opacity: loading ? 0.5 : 1 }} className="img" src={src}
              alt="" />}
          </ProgressiveImage>

        </div>
        <div className="cover__data">
          <div className="cover__title">
            <h1>
              Take ultimate
              <br /> control of your <br />
              home
            </h1>
            <p>
              Ready to dive into the Internet of<br />
              Things to automate your home?
               <br />Start with the top products we've <br />
              tested for every room in the house.
            </p>
            <Button
              className="quoteButton"
              size="large"
              variant="contained"
              color="primary"
            >
              Get instant quote
            </Button>
          </div>
        </div>
      </div>

      <div className="main__cards">
        <h1 className="cardTitle">HSL - HelixSmartLabs make your Home Smart</h1>

        <div className="cards">
          <Box className="card__box" >
            {data2.map((d, index) => (
              <Suspense fallback={<Loading />}>

                <Cards key={index} img={d.img} title={d.title} />
              </Suspense>
            ))}
          </Box>
        </div>
      </div>

      <div className="main__products">
        {data.map((d, index) => (
          <Suspense fallback={<Loading />}>

            <Products key={index} num={index + 1} img={d.img} title={d.title} head={d.head} />
          </Suspense>

        ))}
      </div>
    </div>
  );
}
