import React from "react";
import { Suspense } from "react";
import Loading from "./Loading";
const Cards = React.lazy(() => import("./Card"));
export default function MediaCard() {
  return (
    <div className="website">
      {[1, 2, 3, 4, 5, 6, 7, 8].map((d, index) => (
        <Suspense fallback={<Loading />}>
          <Cards
            key={index}
            img="http://helixsmartlabs.in/image/1.png"
            title="Electro. is an ecommerce platform to purchase gadgets in different price segment."
          />
        </Suspense>
      ))}
    </div>
  );
}
