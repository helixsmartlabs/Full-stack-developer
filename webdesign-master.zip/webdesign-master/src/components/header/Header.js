import React, { useState } from "react";
import Button from "@material-ui/core/Button";
import MenuIcon from "@material-ui/icons/Menu";
import { Link } from "react-router-dom";
import PortfolioButton from "./PortfolioButton";

export default function Header() {
  const [menu, setMenu] = useState(false);

  const show = !menu
    ? "header__middle__main__nav"
    : "header__middle__main__nav show";

  return (
    <div className="header">
      <div className="header__left">

        <Link to="/">
          <img
            className="header__left__logo"
            src="http://helixsmartlabs.in/hsl-image/logo.png"
            alt=""
          />
        </Link>
        <Link to="/">

          <h2 className="logo-title">helixsmartlabs</h2>
        </Link>


      </div>
      <div className="header__middle">
        <ul className={show}>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/about">Shop</Link>
          </li>
          <li>
            <PortfolioButton />
          </li>
          <li>
            <Link to="/about">Blog</Link>
          </li>
        </ul>
      </div>
      <div className="header__right">
        <Button
          className="quoteButton"
          size="small"
          variant="contained"
          color="primary"
        >
          Get instant quote
        </Button>
        <p>Contact</p>
        <MenuIcon onClick={() => setMenu(!menu)} className="menuBar" />
      </div>
    </div>
  );
}
