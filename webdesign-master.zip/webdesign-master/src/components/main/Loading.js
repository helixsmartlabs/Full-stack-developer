import React from 'react';

export default function Loading() {
    return (
        <div className="loading">
            <img className="card-image" src="gray.png" alt=""/>
        </div>
    );
}
