import React, { Component } from 'react';
import GoogleMapReact from 'google-map-react';
import RoomIcon from '@material-ui/icons/Room';
const AnyReactComponent = ({ text }) => <div>{text}</div>;

class Map extends Component {
    static defaultProps = {
        center: {
            lat: 30.733315,
            lng: 76.779419
        },
        zoom: 14
    };

    render() {
        return (
            // Important! Always set the container height explicitly
            <div className="map" style={{ height: '50vh', width: '100%' }}>
                <GoogleMapReact
                    bootstrapURLKeys={{ key: 'AIzaSyBDAWzpfcxxW180ZUlCgbCJnKPB_CLBRcs' }}
                    defaultCenter={this.props.center}
                    defaultZoom={this.props.zoom}
                >
                    <AnyReactComponent
                        lat={30.733315}
                        lng={76.779419}
                        text=<RoomIcon fontSize="large" color="primary"/>
                    />
                </GoogleMapReact>
            </div>
        );
    }
}

export default Map;