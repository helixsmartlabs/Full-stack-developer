import React, { Suspense } from "react";
import "./App.scss";
import Header from "./components/header/Header";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import Main from "./components/main/Main";
import Website from "./components/main/Website";
import Loading from "./components/main/Loading";
const Map = React.lazy(() => import("./components/footer/Map"));
const Footer = React.lazy(() => import("./components/footer/Footer"));

function App() {
  return (
    <div className="app">
      <BrowserRouter>
        <Header />
        <Switch>
          <Route path="/" exact >
            <Main />
            <Suspense  fallback={<Loading />}>
              <Map />
              <Footer />
            </Suspense>
          </Route>
          <Route path="/website" exact component={Website}></Route>
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
