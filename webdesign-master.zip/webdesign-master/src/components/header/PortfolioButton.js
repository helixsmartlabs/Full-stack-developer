import React from 'react';
import Button from '@material-ui/core/Button';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import { makeStyles } from '@material-ui/core/styles';
import { Link } from "react-router-dom";

const useStyles = makeStyles({
    root: {
        background: 'black',
        opacity: '0.9'

    },
    media: {
        color: 'white',
        background: 'black'

    }
});

export default function PortfolioButton() {
    const classes = useStyles();

    const [anchorEl, setAnchorEl] = React.useState(null);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    return (
        <div className="portfolio__but">
            <Button aria-controls="simple-menu" aria-haspopup="true" onClick={handleClick}>
                Portfolio
                 <ArrowDropDownIcon />
            </Button>
            <Menu
                className={classes.root}
                id="simple-menu"
                anchorEl={anchorEl}
                keepMounted

                open={Boolean(anchorEl)}
                onClose={handleClose}
            >
                <Link to="/website">

                    <MenuItem
                        onClick={handleClose}>Website</MenuItem>
                </Link>

                <MenuItem onClick={handleClose}>Application</MenuItem>
                <MenuItem onClick={handleClose}>Software</MenuItem>
                <hr />
                <MenuItem onClick={handleClose}>Business Dashboard</MenuItem>
                <MenuItem onClick={handleClose}>Data Analytics</MenuItem>
                <MenuItem onClick={handleClose}>Digital Marketing</MenuItem>
                <hr />
                <MenuItem onClick={handleClose}>Business Dashboard</MenuItem>
                <MenuItem onClick={handleClose}>Data Analytics</MenuItem>
                <MenuItem onClick={handleClose}>Digital Marketing</MenuItem>
            </Menu>
        </div>
    );
}
