export const data = [
  {
    img: "http://helixsmartlabs.in/hsl-image/lift.png",
    title:
      "Helix smart switches provide versitility to blend in various enviourment such as elevators",
    head: "Elevator Switch"
  },
  {
    img: "http://helixsmartlabs.in/hsl-image/a.png",
    title:
      "Air touch which allows you to control them buy bringing your hand in close proximity",
    head: "Air Touch"

  },
  {
    img: "http://helixsmartlabs.in/hsl-image/b.png",
    title:
      "Helix smart switches are internet enabled smart switch which can be control over the internet",
    head: "Wifi Enabled"

  },
];

export const data2 = [
  {
    img: "http://helixsmartlabs.in/hsl-image/touch.png",
    title: "Air Touch"
  },
  {
    img: "http://helixsmartlabs.in/hsl-image/wifi.png",
    title: "Wifi Enabled"
  },
  {
    img: "http://helixsmartlabs.in/hsl-image/play.png",
    title: "App Controled"
  },
  {
    img: "http://helixsmartlabs.in/hsl-image/waterproof.png",
    title: "Waterproof"
  },
];